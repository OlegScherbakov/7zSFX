#define IDD_COPY  96

#define IDT_COPY           100
#define IDC_COPY           101
#define IDB_COPY_SET_PATH  102
#define IDT_COPY_INFO      103

#define IDS_SET_FOLDER    6007
