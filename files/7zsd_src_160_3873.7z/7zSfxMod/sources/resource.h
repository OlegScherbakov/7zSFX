/*---------------------------------------------------------------------------*/
/* File:        resource.h                                                   */
/* Created:     Sat, 16 Jan 2010 12:09:00 GMT                                */
/*              by Oleg N. Scherbakov, mailto:oleg@7zsfx.info                */
/* Last update: Mon, 22 Mar 2010 11:28:15 GMT                                */
/*              by Oleg N. Scherbakov, mailto:oleg@7zsfx.info                */
/* Revision:    65                                                           */
/*---------------------------------------------------------------------------*/
/* Revision:    65                                                           */
/* Updated:     Mon, 22 Mar 2010 11:28:15 GMT                                */
/*              by Oleg N. Scherbakov, mailto:oleg@7zsfx.info                */
/* Description: New file stamp.                                              */
/*---------------------------------------------------------------------------*/
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 7zSfxMod.rc
//
#define IDI_7ZSFX                       101

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
