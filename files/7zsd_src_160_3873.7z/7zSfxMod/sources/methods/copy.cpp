/*---------------------------------------------------------------------------*/
/* File:        copy.cpp                                                     */
/* Created:     Sat, 20 Nov 2010 10:55:00 GMT                                */
/*              by Oleg N. Scherbakov, mailto:oleg@7zsfx.info                */
/* Last update: Sat, 27 Nov 2010 15:18:14 GMT                                */
/*              by Oleg N. Scherbakov, mailto:oleg@7zsfx.info                */
/* Revision:    8                                                            */
/*---------------------------------------------------------------------------*/
#include "stdafx.h"

#ifdef COMPRESS_COPY
	#include "7zip\Compress\CopyCoder.cpp"
	#include "7zip\Compress\CopyRegister.cpp"
#endif
