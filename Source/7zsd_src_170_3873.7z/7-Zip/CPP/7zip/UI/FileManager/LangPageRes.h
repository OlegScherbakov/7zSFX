#define IDD_LANG     2101
#define IDD_LANG_2  12101

#define IDS_LANG_ENGLISH   1
#define IDS_LANG_NATIVE    2

#define IDT_LANG_LANG   2102
#define IDC_LANG_LANG    100
