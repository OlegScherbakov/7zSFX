// ProgramLocation.cpp

#include "StdAfx.h"
