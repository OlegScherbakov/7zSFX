#include "stdafx.h"
#include "7zSfxModInt.h"

/* #ifdef _MSC_VER
	#if defined(_WIN32) && !defined(_DEBUG) && defined(_MSC_VER_OK) && defined(_SFX_USE_CUSTOM_MSVCRT)
		// only MS VC, only release versions
		#if !defined(_WIN64) && defined(_M_IX86)
#pragma comment( lib, "F:\ICL\lib\msvcrt.lib" )
		#elif defined(_WIN64) && defined(_M_X64)
#pragma comment( lib, "F:\ICL\lib\x64\msvcrt.lib" )
		#endif // platform */
//	#else
		#pragma comment( lib, "MSVCRT98.LIB" )
//	#endif // defined(_WIN32) && !defined(_DEBUG) && defined(_MSC_VER_OK) && defined(_SFX_USE_CUSTOM_MSVCRT)

	#if _MSC_VER == 1900
// sample new & delete operators
void* __CRTDECL operator new[](size_t const size)
{
	return operator new(size);
}

void __CRTDECL operator delete(void* block, size_t)
{
	operator delete(block);
}

void __CRTDECL operator delete[](void* block)
{
	operator delete(block);
}

void __CRTDECL operator delete[](void* block, size_t)
{
	operator delete[](block);
}

	#endif // _MSC_VER == 1900
// #endif // _MSC_VER
