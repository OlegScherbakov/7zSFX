#include "stdafx.h"

#ifdef SFX_CRYPTO
	#include "7zip\Crypto\MyAes.cpp"
	#include "7zip\Crypto\7zAes.cpp"
	#include "7zip\Crypto\7zAesRegister.cpp"

	extern "C" {
		#include "../C/Aes.c"
		#include "../C/Sha256.c"
		#ifndef _SFX_MAINTAINER
			#include "../C/AesOpt.c"
		#endif // _SFX_MAINTAINER
	}
#endif // SFX_CRYPTO
