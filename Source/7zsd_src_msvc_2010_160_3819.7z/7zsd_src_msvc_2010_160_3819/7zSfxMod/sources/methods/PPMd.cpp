#include "stdafx.h"

#ifdef COMPRESS_PPMD
	#include "7zip\Compress\PPMDDecoder.cpp"
	#include "7zip\Compress\PPMDRegister.cpp"
	#include "7zip\Common\CWrappers.cpp"
	#include "..\C\Ppmd7.c"
	#include "..\C\Ppmd7Dec.c"
#endif