#include "stdafx.h"

#ifdef COMPRESS_COPY
	#include "7zip\Compress\CopyCoder.cpp"
	#include "7zip\Compress\CopyRegister.cpp"
#endif
