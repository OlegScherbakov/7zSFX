#include "stdafx.h"

#ifdef COMPRESS_LZMA2
	#include "7zip\Compress\LZMA2Decoder.cpp"
	#include "7zip\Compress\LZMA2Register.cpp"

	extern "C" {
		#ifndef COMPRESS_LZMA
			#include "../C/LzmaDec.c"
		#endif
		#include "../C/Lzma2Dec.c"
	}
#endif