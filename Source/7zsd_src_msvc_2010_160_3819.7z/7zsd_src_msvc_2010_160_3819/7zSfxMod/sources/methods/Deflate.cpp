#include "stdafx.h"

#ifdef COMPRESS_DEFLATE

	#include "7zip\Compress\BitlDecoder.cpp"
	#include "7zip\Compress\LZOutWindow.cpp"
	#include "7zip\Compress\DeflateDecoder.cpp"
	#include "7zip\Compress\DeflateRegister.cpp"

#endif

