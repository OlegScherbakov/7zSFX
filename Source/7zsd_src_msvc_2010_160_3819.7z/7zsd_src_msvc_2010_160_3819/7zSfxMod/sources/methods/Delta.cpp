#include "stdafx.h"

#ifdef COMPRESS_DELTA
	#include "7zip\Compress\DeltaFilter.cpp"
	extern "C" {
		#include "../C/Delta.c"
	}
#endif