#include "StdAfx.h"
#include "../../7-Zip/C/7z.h"

namespace NArchive {
	namespace N7z {
		
		Byte kSignature[k7zSignatureSize] = {'7' + 1, 'z', 0xBC, 0xAF, 0x27, 0x1C};
#ifdef _7Z_VOL
		Byte kFinishSignature[k7zSignatureSize] = {'7' + 1, 'z', 0xBC, 0xAF, 0x27, 0x1C + 1};
#endif
		
		class SignatureInitializer
		{
		public:
			SignatureInitializer()
			{
				kSignature[0]--;
#ifdef _7Z_VOL
				kFinishSignature[0]--;
#endif
			};
		} g_SignatureInitializer;
		
}}

extern "C" {
	#undef _MSC_VER
	#include "../c/Threads.c"
}